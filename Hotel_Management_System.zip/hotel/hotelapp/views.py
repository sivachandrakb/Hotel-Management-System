from django.shortcuts import render
from .models import*
from django.conf import settings
from django.conf.urls.static import static
from django.http import HttpResponse,HttpResponseRedirect 
import datetime
                                    

# COMMON

def welcome(request):
	return render(request,'welcome.html')

def registration(request):

	if request.method=="POST":
		
		fname=request.POST['firstname']
		lname=request.POST['lastname']
		dob=request.POST['Date of bith']
		email=request.POST['email']
		address=request.POST['address']
		pnum=request.POST['phonenumber']
		pin=request.POST['pinnumber']
		vproof=request.FILES['image']
		country=request.POST['country']
		state=request.POST['state']
		uname=request.POST['username']
		pwd=request.POST['password']
		
		usr=tb_users.objects.all().filter(uname=uname) 
		if usr:
			txt="""<script>alert('Email already exist.......');window.location='/registration/';</script>"""
			return HttpResponse(txt)
		else:
			aa=tb_users(fname=fname,lname=lname,dob=dob,email=email,address=address,pnum=pnum,pin=pin,vproof=vproof,country=country,state=state,uname=uname,psw=pwd)
			aa.save()
			return render(request,'welcome.html')
	else:
		return render(request,'registration.html')
def photos(request):
	return render(request,'photos.html')

def login(request):
	if request.method=="POST":
		email=request.POST['uname']
		pwd=request.POST['psw']
		var=tb_users.objects.all().filter(email=email,psw=pwd) 
		mm=tb_admin.objects.all().filter(email=email,pwd=pwd)
		nn=tb_workers.objects.all().filter(email=email,psw=pwd)
		if var:
			for x in var:
				request.session['id']=x.id
				return render(request,'user/userhome.html')
		elif mm:
			for x in mm:
				request.session['id']=x.id
				return render(request,'admin/adminhome.html')
		elif nn:
			for x in nn:
				request.session['id']=x.id
				return render(request,'worker/workerhome.html')
		else:
			return render(request,'login.html')
	else:	
		return render(request,'login.html')
def aboutus(request):
	return render(request,'aboutus.html')

def logout(request):
	if request.session.has_key('id'):
		del request.session['id']
		logout(request)
	return HttpResponseRedirect('/login/')




# ADMIN
def adminhome(request):
	return render(request,'admin/adminhome.html')

def adminviewusers(request):
	var=tb_users.objects.all()
	return render(request,'admin/adminviewusers.html',{'var':var})

def adminaddrooms(request):
	if request.method=="POST":
		
		rcat=request.POST['roomcatogory']
		rcost=request.POST['roomcost']
		bedsz=request.POST['bedsize']
		ftr=request.POST['features']
		spcftr=request.POST['specifications']
		rimg=request.FILES['image']
		aa=tb_rooms(rcat=rcat,rcost=rcost,bedsz=bedsz,ftr=ftr,spcftr=spcftr,rimg=rimg,status='available')
		aa.save()
		return render(request,'admin/adminhome.html')
	else:
		return render(request,'admin/adminaddrooms.html')

def admineditrooms(request):

	myid=request.session['id']
	if request.method=="POST":
		
		rcat=request.POST['roomcatogory']
		rcost=request.POST['roomcost']
		bedsz=request.POST['bedsize']
		ftr=request.POST['features']
		spcftr=request.POST['specifications']
		aa=tb_rooms.objects.all().filter(id=myid).update(rcat=rcat,rcost=rcost,bedsz=bedsz,ftr=ftr,spcftr=spcftr)
		return HttpResponseRedirect('/adminroomlist/')
	else:
		ii=request.GET['id']
		var=tb_rooms.objects.all().filter(id=ii)
		return render(request,'admin/admineditrooms.html',{'var':var})

def adminaddworker(request):
	return render(request,'admin/adminaddworker.html')

def adminaddfood(request):
	if request.method=="POST":
		ftype=request.POST['type']
		starters=request.POST['starters']
		mlnfood=request.POST['mlnfood']
		fname=request.POST['fname']
		fcost=request.POST['fcost']
		sfname=request.POST['sfname']
		sfcost=request.POST['sfcost']
		image=request.FILES['image']
		aa=tb_food(ftype=ftype,starters=starters,mlnfood=mlnfood,fname=fname,fcost=fcost,sfname=sfname,sfcost=sfcost,image=image)
		aa.save()
		return render(request,'admin/adminhome.html')
	else:
		return render(request,'admin/adminaddfood.html')

def adminviewfood(request):
	var=tb_food.objects.all()
	return render(request,'admin/adminviewfood.html',{'var':var})

def admineditfood(request):
	myid=request.session['id']
	if request.method=="POST":
		ftype=request.POST['type']
		starters=request.POST['starters']
		mlnfood=request.POST['mlnfood']
		fname=request.POST['fname']
		fcost=request.POST['fcost']
		sfname=request.POST['sfname']
		sfcost=request.POST['sfcost']
		aa=tb_food.objects.all().filter(id=myid).update(ftype=ftype,starters=starters,mlnfood=mlnfood,fname=fname,fcost=fcost,sfname=sfname,sfcost=sfcost)
		return HttpResponseRedirect('/adminviewfood/')

	else:
		ii=request.GET['id']
		
		var=tb_food.objects.all().filter(id=ii)
		return render(request,'admin/admineditfood.html',{'var':var,})


def adminavailablerooms(request):
	var=tb_rooms.objects.all().filter(status='available')
	return render(request,'admin/adminavailablerooms.html',{'var':var})

def adminroomlist(request):
	var=tb_rooms.objects.all()
	return render(request,'admin/adminroomlist.html',{'var':var})

def adminviewfeedback(request):
	var=tb_userfeedback.objects.all()
	return render(request,'admin/adminviewfeedback.html',{'var':var})

def adminviewcomplaints(request):
	var=tb_workerscomplaints.objects.all()
	return render(request,'admin/adminviewcomplaints.html',{'var':var})

def adminaddworker(request):
	if request.method=="POST":
		email=request.POST['email']
		name=request.POST['name']
		pnum=request.POST['pnum']
		catogory=request.POST['catogory']
		uname=request.POST['uname']
		place=request.POST['place']
		psw=request.POST['psw']
		aa=tb_workers(email=email,name=name,pnum=pnum,catogory=catogory,uname=uname,place=place,psw=psw)
		aa.save()
		return render(request,'admin/adminhome.html')
	else:
		return render(request,'admin/adminaddworker.html')

def adminviewworkers(request):
	var=tb_workers.objects.all()
	return render(request,'admin/adminviewworkers.html',{'var':var})

def adminbookings(request):
	return render(request,'admin/adminbookings.html')

def adminallotworkers(request):
	return render(request,'admin/adminallotworkers.html')

def allotcleaning(request):
	if request.method=="POST":
		worker=request.POST['worker']
		orid=request.POST['id']
		aa=tb_orders.objects.all().filter(id=orid).update(roomcleaning=worker)
		return HttpResponseRedirect('/allotcleaning/')
	else:
		var=tb_orders.objects.all().filter(roomcleaning__isnull=True)
		wrk=tb_workers.objects.all().filter(catogory='cleaning')
		# idd=request.GET['idd']
		return render(request,'admin/allotcleaning.html',{'var':var,'wrk':wrk})
# def allotwork(request):
# 	if request.method=="POST":
# 		worker=request.POST['worker']
# 		orid=request.POST['idd']
# 		aa=tb_orders.objects.all().filter(id=orid).update(roomcleaning=worker)
# 		return HttpResponseRedirect('/allotcleaning/')
# 	else:
# 		return HttpResponseRedirect('/allotcleaning/')

def allotfood(request):
	if request.method=="POST":
		worker=request.POST['worker']
		orid=request.POST['id']
		aa=tb_orders.objects.all().filter(id=orid).update(foodservice=worker)
		return HttpResponseRedirect('/allotfood/')
	else:
		var=tb_orders.objects.all().filter(foodservice__isnull=True)
		wrk=tb_workers.objects.all().filter(catogory='food')
		# idd=request.GET['idd']
		return render(request,'admin/allotfood.html',{'var':var,'wrk':wrk})

def allotroomservice(request):
	if request.method=="POST":
		worker=request.POST['worker']
		orid=request.POST['id']
		aa=tb_orders.objects.all().filter(id=orid).update(roomservice=worker)
		return HttpResponseRedirect('/allotroomservice/')
	else:
		var=tb_orders.objects.all().filter(roomservice__isnull=True)
		wrk=tb_workers.objects.all().filter(catogory='roomservice')
		# idd=request.GET['idd']
		return render(request,'admin/allotroomservice.html',{'var':var,'wrk':wrk})

# USER
def userhome(request):
	return render(request,'user/userhome.html')

def profile(request):
	myid=request.session['id']
	var=tb_users.objects.all().filter(id=myid)
	return render(request,'user/profile.html',{'var':var}) 

def userviewavailablerooms(request):
	var=tb_rooms.objects.all().filter(status='available')
	return render(request,'user/userviewavailablerooms.html',{'var':var})

def useravailable_singlerooms(request):
	var=tb_rooms.objects.all().filter(rcat='Single Room',status='available')
	return render(request,'user/userviewavailablerooms.html',{'var':var})

def useravailable_doublerooms(request):
	var=tb_rooms.objects.all().filter(rcat='Double Room',status='available')
	return render(request,'user/userviewavailablerooms.html',{'var':var})

def useravailable_deluxerooms(request):
	var=tb_rooms.objects.all().filter(rcat='Delux Room',status='available')
	return render(request,'user/userviewavailablerooms.html',{'var':var})

def usereditprofile(request):
	myid=request.session['id']
	if request.method=="POST":
		
		fname=request.POST['firstname']
		lname=request.POST['lastname']
		dob=request.POST['Date of bith']
		email=request.POST['email']
		address=request.POST['address']
		pnum=request.POST['phonenumber']
		pin=request.POST['pinnumber']
		
		country=request.POST['country']
		state=request.POST['state']
		uname=request.POST['username']
		pwd=request.POST['password']

		aa=tb_users.objects.all().filter(id=myid).update(fname=fname,lname=lname,dob=dob,email=email,address=address,pnum=pnum,pin=pin,country=country,state=state,uname=uname,psw=pwd)
		return HttpResponseRedirect('/profile/')
	else:
		var=tb_users.objects.all().filter(id=myid)
		return render(request,'user/usereditprofile.html',{'var':var,})



def userfeedback(request):
	myid=request.session['id']
	var=tb_users.objects.all().filter(id=myid)
	if request.method=='POST':
		ui=tb_users.objects.get(id=myid)
		feedback=request.POST['feedback']	
		aa=tb_userfeedback(user_id=ui,feedback=feedback)
		aa.save()
		return HttpResponseRedirect('/userhome/')
	else:
		return render(request,'user/userfeedback.html',{'var':var})

def userpayment(request):
	myid=request.session['id']

	if request.method=="POST":
		# date=datetime.datetime.now()
		# idd=request.POST['getid']
		# uid=tb_users.objects.get(id=myid)
		# rid=tb_rooms.objects.get(id=idd)
		# aa=tb_rooms.objects.all().filter(id=idd).update(status='booked')
		# var=tb_orders(user_id=uid,room_id=rid,date=date,status='pending')
		# var.save()
		# # ii=request.GET['id']
		return HttpResponseRedirect('/userhome/')
	else:
		myid=request.session['id']
		var=tb_orders.objects.all().filter(user_id=myid)

		for x in var:
			rid =x.room_id
			fid=x.food_id
			room_cost=x.room_id.rcost
		print(room_cost,"___________")
		bill=int(room_cost)+int(3)
		return render(request,'user/userpayment.html',{'room_cost':room_cost,'bill':bill})
# def order_rooms(request):
# 	# myid=request.session['id']
# 	# getid=request.GET['id']
# 	# date=datetime.datetime.now()
# 	# uid=tb_users.objects.get(id=myid)
# 	# rid=tb_rooms.objects.get(id=getid)
# 	# aa=tb_rooms.objects.all().filter(id=getid).update(status='booked')
# 	# var=tb_orders(user_id=uid,room_id=rid,date=date,status='pending')
# 	# var.save()
# 	return HttpResponseRedirect('/userpayment/')

def userextra(request):
	var=tb_food.objects.all()
	return render(request,'user/userextra.html',{'var':var})


def orderfood(request):
	ii=request.GET['id']
	fid=tb_food.objects.get(id=ii)
	myid=request.session['id']
	aa=tb_orders.objects.all().filter(user_id=myid).update(food_id=fid)
	tot=tb_orders.objects.all().filter(user_id=myid)
	for x in tot:
		rid=x.room_id
		fid=x.food_id
		room_cost=x.room_id.rcost
		food_cost=x.food_id.fcost
		food_scost=x.food_id.sfcost
		print(room_cost,"____________")
	bill=int(room_cost)+int(food_cost)+int(food_scost)
	return HttpResponseRedirect('/userpayment1/')

def userpayment1(request):
	myid=request.session['id']
	if request.method=='POST':
		return HttpResponseRedirect('/userhome/')
	else:
		myid=request.session['id']
		aa=tb_orders.objects.all().filter(user_id=myid)
		for x in aa:
			rid=x.room_id
			fid=x.food_id
			room_cost=x.room_id.rcost
			food_cost=x.food_id.fcost
			food_scost=x.food_id.sfcost
		print(room_cost,"__________")
		bill=int(room_cost)+int(3)+int(food_cost)+int(food_scost)
		return render(request,'user/userpayment.html',{'room_cost':room_cost,'food_cost':food_cost,'food_scost':food_scost,'bill':bill})




def userchoose(request):
	date=datetime.datetime.now()
	idd=request.GET['id']
	myid=request.session['id']
	uid=tb_users.objects.get(id=myid)
	rid=tb_rooms.objects.get(id=idd)
	aa=tb_rooms.objects.all().filter(id=idd).update(status='booked')
	bb=tb_orders(user_id=uid,room_id=rid,date=date,status='pending')
	bb.save()
	return render(request,'user/userchoose.html')

	
#WORKERS
def workerhome(request):
	return render(request,'worker/workerhome.html')

def workerprofile(request):
	myid=request.session['id']
	var=tb_workers.objects.all().filter(id=myid)
	return render(request,'worker/workerprofile.html',{'var':var})

def workercomplaints(request):
	myid=request.session['id']
	var=tb_workers.objects.all().filter(id=myid)
	if request.method=='POST':
		ui=tb_workers.objects.get(id=myid)
		complaint=request.POST['complaint']	
		aa=tb_workerscomplaints(worker_id=ui,complaint=complaint)
		aa.save()
		return HttpResponseRedirect('/workerhome/')
	else:
		return render(request,'worker/workercomplaints.html',{'var':var})

def workereditprofile(request):

	myid=request.session['id']
	if request.method=="POST":
		
		name=request.POST['name']
		uname=request.POST['uname']
		pnum=request.POST['pnum']
		catogory=request.POST['catogory']
		place=request.POST['place']
		psw=request.POST['psw']
		aa=tb_workers.objects.all().filter(id=myid).update(name=name,uname=uname,pnum=pnum,catogory=catogory,psw=psw)
		return HttpResponseRedirect('/workerprofile/')
	else:
		# ii=request.GET['id']
		var=tb_workers.objects.all().filter(id=myid)
		return render(request,'worker/workereditprofile.html',{'var':var})

def workalloted(request):
	myid=request.session['id']
	wname=tb_workers.objects.all().filter(id=myid)
	for x in wname:
		email=x.email
	mm=tb_orders.objects.all()
	for x in mm:
		foodservice=x.foodservice
		roomservice=x.roomservice
		roomcleaning=x.roomcleaning
	var=tb_orders.objects.all().filter(foodservice=email)
	print("+++++++++++++++",var)
	var2=tb_orders.objects.all().filter(roomservice=email)
	var3=tb_orders.objects.all().filter(roomcleaning=email)
	return render(request,'worker/workalloted.html',{'var':var,'var2':var2,'var3':var3})

def completework(request):
	getid=request.GET['id']
	ab=tb_orders.objects.all().filter(id=getid).update(status='completed')
	return HttpResponseRedirect('/workerhome/')

	