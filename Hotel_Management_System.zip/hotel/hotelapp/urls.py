from django.contrib import admin
from django.urls import path ,include
from .import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [

       path('',views.welcome),
       path('registration/',views.registration),
       path('photos/',views.photos),
       path('login/',views.login),
       path('aboutus/',views.aboutus),
       path('adminhome/',views.adminhome),
       path('userhome/',views.userhome),
       path('profile/',views.profile), 
       path('logout/',views.logout),
       path('adminviewusers/',views.adminviewusers),
       path('adminaddrooms/',views.adminaddrooms),
       path('adminaddrooms/',views.adminaddrooms),
       path('adminaddworker/',views.adminaddworker),
       path('adminavailablerooms/',views.adminavailablerooms),
       path('adminroomlist/',views.adminroomlist),
       path('useravailable_singlerooms/',views.useravailable_singlerooms),
       path('useravailable_doublerooms/',views.useravailable_doublerooms),
       path('useravailable_deluxerooms/',views.useravailable_deluxerooms),
       path('userviewavailablerooms/',views.userviewavailablerooms),
       path('usereditprofile/',views.usereditprofile),
       path('userpayment/',views.userpayment),
       path('userfeedback/',views.userfeedback),
       path('adminviewfeedback/',views.adminviewfeedback),
       path('adminviewcomplaints/',views.adminviewcomplaints),
       # path('order_rooms/',views.order_rooms),
       path('adminaddfood/',views.adminaddfood),
       path('adminviewfood/',views.adminviewfood),
       path('admineditfood/',views.admineditfood),
       path('admineditrooms/',views.admineditrooms),
       path('userextra/',views.userextra),
       path('orderfood/',views.orderfood),
       path('userpayment1/',views.userpayment1),
       # path('userpayment2/',views.userpayment2),
       path('adminviewworkers/',views.adminviewworkers),
       path('adminbookings/',views.adminbookings),
       path('adminallotworkers/',views.adminallotworkers),
       path('workerprofile/',views.workerprofile),
       path('workerhome/',views.workerhome),
       path('workereditprofile/',views.workereditprofile),
       path('workercomplaints/',views.workercomplaints),
       path('userchoose/',views.userchoose ),
       path('allotcleaning/',views.allotcleaning ),
       path('allotfood/',views.allotfood ),
       path('workalloted/',views.workalloted ),
       path('completework/',views.completework ),
       path('allotroomservice/',views.allotroomservice ),












       
]
if settings.DEBUG:urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)