from django.db import models

class tb_users(models.Model):
	fname=models.CharField(max_length=100,default='')
	lname=models.CharField(max_length=100,default='')
	dob=models.CharField(max_length=100,default='')
	email=models.CharField(max_length=100,default='')
	address=models.CharField(max_length=100,default='')
	pnum=models.CharField(max_length=100,default='')
	pin=models.CharField(max_length=100,default='')
	vproof=models.ImageField(upload_to='pic/',default='')
	country=models.CharField(max_length=100,default='')
	state=models.CharField(max_length=100,default='')
	uname=models.CharField(max_length=100,default='')
	psw=models.CharField(max_length=100,default='')

class tb_admin(models.Model):
	email=models.CharField(max_length=100,default='')
	pwd=models.CharField(max_length=100,default='')

class tb_userfeedback(models.Model):
	user_id=models.ForeignKey(tb_users,on_delete=models.CASCADE,default='',null=True)
	feedback=models.CharField(max_length=100,default='')

class tb_rooms(models.Model):
	rcat=models.CharField(max_length=100,default='')
	rcost=models.CharField(max_length=100,default='')
	bedsz=models.CharField(max_length=100,default='')
	ftr=models.CharField(max_length=100,default='')
	spcftr=models.CharField(max_length=100,default='')
	rimg=models.ImageField(upload_to='pic/',default='')
	status=models.CharField(max_length=100,default='')

class tb_food(models.Model):
	ftype=models.CharField(max_length=100,default='')
	starters=models.CharField(max_length=100,default='')
	mlnfood=models.CharField(max_length=100,default='')
	fname=models.CharField(max_length=100,default='')
	fcost=models.CharField(max_length=100,default='')
	sfname=models.CharField(max_length=100,default='')
	sfcost=models.CharField(max_length=100,default='')
	image=models.ImageField(upload_to='pic/',default='')
	status=models.CharField(max_length=100,default='') 


class tb_orders(models.Model):
	user_id=models.ForeignKey(tb_users,on_delete=models.CASCADE,default='',null=True)
	room_id=models.ForeignKey(tb_rooms,on_delete=models.CASCADE,default='',null=True)
	food_id=models.ForeignKey(tb_food,on_delete=models.CASCADE,default='',null=True)
	date=models.CharField(max_length=100,default='')
	status=models.CharField(max_length=100,default='')
	roomcleaning=models.CharField(max_length=100,null='True')
	roomservice=models.CharField(max_length=100,null='True')
	foodservice=models.CharField(max_length=100,null='True')




class tb_workers(models.Model):
	name=models.CharField(max_length=100,default='')
	uname=models.CharField(max_length=100,default='')
	place=models.CharField(max_length=100,default='' )
	email=models.CharField(max_length=100,default='')
	psw=models.CharField(max_length=100,default='')
	pnum=models.CharField(max_length=100,default='')
	catogory=models.CharField(max_length=100,default='')

class tb_workerscomplaints(models.Model):
	worker_id=models.ForeignKey(tb_workers,on_delete=models.CASCADE,default='',null=True)
	complaint=models.CharField(max_length=100,default='')


